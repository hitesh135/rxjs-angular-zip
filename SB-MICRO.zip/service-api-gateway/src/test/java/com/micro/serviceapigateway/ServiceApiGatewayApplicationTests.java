package com.micro.serviceapigateway;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ServiceApiGatewayApplicationTests {

	@Test
	void contextLoads() {
	}

}
