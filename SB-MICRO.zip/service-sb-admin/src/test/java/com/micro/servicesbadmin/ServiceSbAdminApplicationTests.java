package com.micro.servicesbadmin;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ServiceSbAdminApplicationTests {

	@Test
	void contextLoads() {
	}

}
